﻿namespace SignalR_AnlikMesajlasma.Models
{
    public class Message
    {
       
            public int Id { get; set; }
            public string? User { get; set; }            
            public string? Text { get; set; }     
            public DateTime Timestamp { get; set; } = DateTime.Now;

            public int? SenderUserId { get; set; }
            public int? ReceiverUserId { get; set; }
            public bool IsPrivate { get; set; }


    }

}
