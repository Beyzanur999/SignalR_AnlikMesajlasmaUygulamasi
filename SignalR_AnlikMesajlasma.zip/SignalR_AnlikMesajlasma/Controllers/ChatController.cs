﻿using Microsoft.AspNetCore.Mvc;
using SignalR_AnlikMesajlasma.Data;
using SignalR_AnlikMesajlasma.Models;

namespace SignalR_AnlikMesajlasma.Controllers
{
    public class ChatController : Controller
    {
        private readonly AppDbContext _context;

        public ChatController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var username = HttpContext.Session.GetString("Username");
            if (string.IsNullOrEmpty(username))
                return RedirectToAction("Login", "Account");

            var user = _context.Users.FirstOrDefault(u => u.Username == username);
            if (user == null)
            {
                HttpContext.Session.Clear();
                return RedirectToAction("Login", "Account");
            }

            var messages = _context.Messages
                .Where(m => !m.IsPrivate && (user.LastClearTime == null || m.Timestamp > user.LastClearTime))
                .OrderBy(m => m.Timestamp)
                .ToList();

            return View(messages);
        }

        public IActionResult UserList()
        {
            var userIdStr = HttpContext.Session.GetString("UserId");
            if (string.IsNullOrEmpty(userIdStr))
                return RedirectToAction("Login", "Account");

            int currentUserId = int.Parse(userIdStr);
            var users = _context.Users
                .Where(u => u.Id != currentUserId)
                .ToList();

            return View(users);
        }

        [HttpPost]
        public IActionResult ClearHistory()
        {
            var username = HttpContext.Session.GetString("Username");
            if (string.IsNullOrEmpty(username))
                return RedirectToAction("Login", "Account");

            var user = _context.Users.FirstOrDefault(u => u.Username == username);
            if (user != null)
            {
                user.LastClearTime = DateTime.Now;
                _context.SaveChanges();
            }

            return RedirectToAction("Index");
        }
    }
}
