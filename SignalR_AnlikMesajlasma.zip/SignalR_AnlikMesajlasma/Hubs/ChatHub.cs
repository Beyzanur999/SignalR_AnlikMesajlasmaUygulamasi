﻿using Microsoft.AspNetCore.SignalR;
using SignalR_AnlikMesajlasma.Data;
using SignalR_AnlikMesajlasma.Models;

namespace SignalR_AnlikMesajlasma.Hubs
{
    public class ChatHub : Hub
    {
        private readonly AppDbContext _context;
        private static Dictionary<string, int> _connectedUsers = new(); // connectionId => userId

        public ChatHub(AppDbContext context)
        {
            _context = context;
        }

        public override Task OnConnectedAsync()
        {
            var httpContext = Context.GetHttpContext();
            if (httpContext != null)
            {
                var userIdStr = httpContext.Session.GetString("UserId");
                if (int.TryParse(userIdStr, out int userId))
                {
                    _connectedUsers[Context.ConnectionId] = userId;
                }
            }
            return base.OnConnectedAsync();
        }

        public override Task OnDisconnectedAsync(Exception? exception)
        {
            _connectedUsers.Remove(Context.ConnectionId);
            return base.OnDisconnectedAsync(exception);
        }

        public async Task SendMessage(string message)
        {
            var username = Context.GetHttpContext()?.Session.GetString("Username");
            if (string.IsNullOrEmpty(username))
                return;

            var newMessage = new Message
            {
                User = username,
                Text = message,
                IsPrivate = false,
                Timestamp = DateTime.Now
            };

            _context.Messages.Add(newMessage);
            await _context.SaveChangesAsync();

            await Clients.All.SendAsync("ReceiveMessage", newMessage.User, newMessage.Text, newMessage.Timestamp.ToString("HH:mm"));
        }

        public async Task SendPrivateMessage(int receiverUserId, string message)
        {
            var senderUserIdStr = Context.GetHttpContext()?.Session.GetString("UserId");
            var senderUsername = Context.GetHttpContext()?.Session.GetString("Username");

            if (!int.TryParse(senderUserIdStr, out int senderUserId) || string.IsNullOrEmpty(senderUsername))
                return;

            var msg = new Message
            {
                User = senderUsername,
                Text = message,
                Timestamp = DateTime.Now,
                SenderUserId = senderUserId,
                ReceiverUserId = receiverUserId,
                IsPrivate = true
            };

            _context.Messages.Add(msg);
            await _context.SaveChangesAsync();

            // Receiver'a mesajı gönder
            var receiverConnectionIds = _connectedUsers
                .Where(x => x.Value == receiverUserId)
                .Select(x => x.Key)
                .ToList();

            foreach (var connId in receiverConnectionIds)
            {
                await Clients.Client(connId).SendAsync("ReceivePrivateMessage", senderUsername, message, msg.Timestamp.ToString("HH:mm"));
            }
        }
    }
}
